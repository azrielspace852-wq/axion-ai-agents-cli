const CACHE_NAME = 'azriel-space-v8';
const urlsToCache = [
    './',
    './index.html',
    './manifest.json',
    './logo.png',
    './profil.png',
    'https://cdn.jsdelivr.net/npm/marked/marked.min.js'
];

self.addEventListener('install', event => {
    event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)));
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => response || fetch(event.request))
    );
});